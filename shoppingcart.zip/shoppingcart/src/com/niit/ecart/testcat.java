package com.niit.ecart;

public class testcat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       catagary cat = new catagary();
       cat.setCat_id("PR771");
       cat.setCat_name("laptop");
       cat.setCat_description();
	}
}

       
       
       
       
	



