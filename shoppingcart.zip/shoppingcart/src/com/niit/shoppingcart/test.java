package com.niit.shoppingcart;

public class test {
public static void main(String[] args) {
	//create instance or object
	//classname object = new constructer name ();
    product product = new product();
   
    
    product.setId("PR01");
    product.setName("mobileproduct");
    product.setPrice(15000);
    
    System.out.println(product.getId());
    System.out.println(product.getName());
    
    System.out.println(product.getPrice());
} 
}